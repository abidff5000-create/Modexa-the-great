Modexá 121 - Android project

Phone theke build (GitHub Actions):
1. Zip ta (Modexa121-pro.zip) GitHub repo te upload koro. Ager zip delete koro.
2. .github/workflows/build.yml e ei zip er workflow paste koro.
3. Actions tab > run shesh hole Artifacts > Modexa-121-APK download koro.

PC theke: Android Studio > Open > Modexa121 folder > Build APK(s).
