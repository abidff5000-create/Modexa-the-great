package com.modexa.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * Modexá 121 - Discord web in a WebView with the Modexá script
 * (UI panel + audio engine, assets/inject.js) injected before the page loads.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var offline: View

    private val startUrl = "https://discord.com/app"
    private val script by lazy { assets.open("inject.js").bufferedReader().use { it.readText() } }
    private var docStartInjected = false
    private var hadError = false

    private var pendingRequest: PermissionRequest? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            )
            fileCallback = null
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            startVoiceService()
            val req = pendingRequest ?: return@registerForActivityResult
            pendingRequest = null
            grantAllowed(req)
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        progress = findViewById(R.id.progress)
        offline = findViewById(R.id.offline)
        findViewById<Button>(R.id.retry).setOnClickListener {
            offline.visibility = View.GONE
            hadError = false
            web.loadUrl(startUrl)
        }

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            // Discord blocks voice on mobile user agents, so present a desktop browser.
            userAgentString =
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
            useWideViewPort = true
            loadWithOverviewMode = false
            setSupportZoom(false)
            builtInZoomControls = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        // Preferred: run the script at document start, before Discord's own code (like a content script).
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(
                    web, script, setOf("https://discord.com", "https://*.discord.com")
                )
                docStartInjected = true
            } catch (e: Exception) {
                docStartInjected = false
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                hadError = false
                // Fallback for old WebView versions without DOCUMENT_START_SCRIPT.
                if (!docStartInjected && url?.contains("discord.com") == true) {
                    view.evaluateJavascript(script, null)
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!hadError) offline.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    hadError = true
                    offline.visibility = View.VISIBLE
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val host = request.url.host ?: return false
                val internal = host == "discord.com" || host.endsWith(".discord.com") ||
                    host == "discordapp.com" || host.endsWith(".discordapp.com") ||
                    host == "discord.gg"
                if (internal) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    true
                } catch (e: Exception) {
                    false
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val missing = missingPermissions(request)
                    if (missing.isEmpty()) {
                        grantAllowed(request)
                    } else {
                        pendingRequest?.deny()
                        pendingRequest = request
                        permLauncher.launch(missing.toTypedArray())
                    }
                }
            }

            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.setDownloadListener { url, _, _, _, _ ->
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) { /* no handler */ }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
            }
        })

        // Ask for mic (and notification permission on Android 13+) up front.
        val startup = mutableListOf<String>()
        if (!has(Manifest.permission.RECORD_AUDIO)) startup += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            startup += Manifest.permission.POST_NOTIFICATIONS
        }
        if (startup.isNotEmpty()) permLauncher.launch(startup.toTypedArray()) else startVoiceService()

        if (savedInstanceState == null) web.loadUrl(startUrl) else web.restoreState(savedInstanceState)
    }

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun missingPermissions(req: PermissionRequest): List<String> {
        val list = mutableListOf<String>()
        if (req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
            !has(Manifest.permission.RECORD_AUDIO)
        ) list += Manifest.permission.RECORD_AUDIO
        if (req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
            !has(Manifest.permission.CAMERA)
        ) list += Manifest.permission.CAMERA
        return list
    }

    /** Grants only the resources the Android runtime permissions actually allow. */
    private fun grantAllowed(req: PermissionRequest) {
        val allowed = req.resources.filter {
            when (it) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> has(Manifest.permission.RECORD_AUDIO)
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> has(Manifest.permission.CAMERA)
                else -> true
            }
        }
        try {
            if (allowed.isEmpty()) req.deny() else req.grant(allowed.toTypedArray())
        } catch (e: Exception) { /* request already handled */ }
    }

    private fun startVoiceService() {
        if (!has(Manifest.permission.RECORD_AUDIO)) return
        try {
            ContextCompat.startForegroundService(this, Intent(this, VoiceService::class.java))
        } catch (e: Throwable) { /* service is optional */ }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    // Note: no web.onPause()/onResume() on purpose, so a voice call keeps running in the background.

    override fun onDestroy() {
        try { stopService(Intent(this, VoiceService::class.java)) } catch (e: Throwable) { }
        web.destroy()
        super.onDestroy()
    }
}
